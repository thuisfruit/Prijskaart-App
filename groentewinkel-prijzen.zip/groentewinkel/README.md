# 🥦 Groentewinkel Prijsbeheer

## Stap-voor-stap online zetten (doe dit op een laptop)

---

### STAP 1 — Supabase instellen (database + inloggen)

1. Ga naar https://supabase.com en log in
2. Klik **New Project** → geef het een naam (bijv. "groentewinkel") → wacht ~1 minuut
3. Ga naar **SQL Editor** (linkermenu)
4. Kopieer de volledige inhoud van het bestand `supabase-setup.sql`
5. Plak het in de SQL Editor → klik **Run**
6. Ga naar **Project Settings → API**
7. Kopieer de **Project URL** en de **anon/public key**

---

### STAP 2 — GitHub repo aanmaken

1. Ga naar https://github.com → klik **New repository**
2. Naam: `groentewinkel-prijzen` → klik **Create repository**
3. Upload alle bestanden uit deze map naar GitHub
   - Klik **uploading an existing file** op de GitHub pagina
   - Sleep alle bestanden erin (let op: ook de `src/` map)
   - Klik **Commit changes**

---

### STAP 3 — Vercel koppelen

1. Ga naar https://vercel.com → log in → klik **Add New Project**
2. Kies je GitHub repo `groentewinkel-prijzen`
3. Klik **Deploy** — Vercel herkent automatisch dat het een Vite/React app is

---

### STAP 4 — Supabase sleutels toevoegen aan Vercel

Na de eerste deploy (die mislukt omdat de sleutels nog ontbreken):

1. Ga in Vercel naar je project → **Settings → Environment Variables**
2. Voeg toe:
   - `VITE_SUPABASE_URL` → jouw Project URL uit stap 1
   - `VITE_SUPABASE_ANON_KEY` → jouw anon key uit stap 1
3. Klik **Save** → ga naar **Deployments** → klik **Redeploy**

---

### STAP 5 — App is online! 🎉

Je krijgt een link zoals: `groentewinkel-prijzen.vercel.app`

**Collega's toevoegen:**
- Stuur ze de link
- Ze maken zelf een account aan op de loginpagina
- Ze kunnen direct inloggen — er is geen goedkeuring nodig

**Eigen domeinnaam (optioneel):**
- Koop een domein bij Transip.nl (~€10/jaar)
- Koppel het in Vercel → Settings → Domains

---

### Kosten overzicht

| Service  | Kosten          |
|----------|-----------------|
| Supabase | Gratis (tot 500MB) |
| Vercel   | Gratis          |
| GitHub   | Gratis          |
| Domein   | ~€10/jaar (optioneel) |

**Totaal: €0 per maand** (of €10/jaar met eigen domeinnaam)

---

### Problemen?

Open een nieuw gesprek in Claude en beschrijf wat er mis gaat — ik help je verder.
