-- ============================================================
-- PLAK DIT IN SUPABASE → SQL EDITOR → RUN
-- Dit maakt alle benodigde tabellen aan
-- ============================================================

-- Producten tabel
create table if not exists producten (
  id        bigint generated always as identity primary key,
  cat       text not null default 'Groente',
  naam      text not null,
  eenheid   text not null default 'per kg',
  inkoop    numeric(10,2) not null default 0,
  opslag    numeric(10,2) not null default 30,
  btw       numeric(5,2)  not null default 9,
  land      text          default 'Nederland',
  actie     text          default '',
  actief    boolean       not null default true,
  gewijzigd text          default '',
  created_at timestamptz  default now()
);

-- Instellingen tabel (1 rij voor de hele winkel)
create table if not exists instellingen (
  id         int primary key default 1,
  winkelnaam text    default 'Mijn Groentewinkel',
  opslag     numeric default 30,
  btw        numeric default 9,
  min_marge  numeric default 20,
  max_marge  numeric default 50
);

-- Voeg standaard instellingen in
insert into instellingen (id) values (1) on conflict do nothing;

-- Beveiliging: alleen ingelogde gebruikers mogen lezen/schrijven
alter table producten    enable row level security;
alter table instellingen enable row level security;

create policy "Ingelogde gebruikers kunnen producten lezen"
  on producten for select using (auth.role() = 'authenticated');

create policy "Ingelogde gebruikers kunnen producten aanpassen"
  on producten for all using (auth.role() = 'authenticated');

create policy "Ingelogde gebruikers kunnen instellingen lezen"
  on instellingen for select using (auth.role() = 'authenticated');

create policy "Ingelogde gebruikers kunnen instellingen aanpassen"
  on instellingen for all using (auth.role() = 'authenticated');
